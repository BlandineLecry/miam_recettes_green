const db = require("../db");

// Ajouter une recette
exports.addRecipe = async (req, res) => {
  const {
    title,
    ingredients,
    instructions,
    image_name,
    cleaned_ingredients,
    userId,
  } = req.body;
  try {
    await db.query(
      "INSERT INTO recettes (title, ingredients, instructions, image_name, cleaned_ingredients, user_id) VALUES (?, ?, ?, ?, ?, ?)",
      [
        title,
        ingredients,
        instructions,
        image_name,
        cleaned_ingredients,
        userId,
      ]
    );
    res.status(201).json({ message: "Recette ajoutée !" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Modifier une recette
exports.updateRecipe = async (req, res) => {
  const { id } = req.params;
  const {
    title,
    ingredients,
    instructions,
    image_name,
    cleaned_ingredients,
    userId,
  } = req.body;
  try {
    const [recettes] = await db.query(
      "SELECT * FROM recettes WHERE id = ? AND user_id = ?",
      [id, userId]
    );
    if (recettes.length === 0) {
      return res.status(403).json({ error: "Pas autorisé" });
    }

    await db.query(
      "UPDATE recettes SET title = ?, ingredients = ?, instructions = ?, image_name = ?, cleaned_ingredients = ? WHERE id = ?",
      [title, ingredients, instructions, image_name, cleaned_ingredients, id]
    );
    res.json({ message: "Recette mise à jour !" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Récupérer les recettes de l'utilisateur connecté
exports.getUserRecipes = async (req, res) => {
  const { userId } = req.body;
  try {
    const [recettes] = await db.query(
      "SELECT * FROM recettes WHERE user_id = ?",
      [userId]
    );
    res.json(recettes);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
