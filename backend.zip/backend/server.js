app.get('/recettes', (req, res) => {
  console.log('Requête GET /recettes reçue');
  db.query('SELECT * FROM recettes LIMIT 50', (err, results) => {
    if (err) {
      console.error('Erreur SQL :', err);
      console.log('Erreur 500 renvoyée au client');
      return res.status(500).json({ error: 'Erreur serveur' });
    }
    console.log('Résultats SQL récupérés avec succès');
    console.log('Réponse JSON envoyée au client');
    res.json(results);
  });
});const express = require('express');
const mysql = require('mysql');
const cors = require('cors');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'recettes'
});

db.connect(err => {
  if (err) {
    console.error('Erreur de connexion :', err);
    return;
  }
  console.log('Connecté à MySQL');
});

app.get('/recettes', (req, res) => {
  db.query('SELECT * FROM recettes LIMIT 50', (err, results) => {
    if (err) {
      console.error('Erreur SQL :', err);
      return res.status(500).json({ error: 'Erreur serveur' });
    }
    res.json(results);
  });
});

app.listen(PORT, () => {
  console.log(`Serveur API lancé sur http://localhost:${PORT}`);
});

// Pour laisser le serveur en écoute
const router = express.Router();
const secretKey = 'votre_cle_secrete';

// Endpoint pour l'inscription
router.post('/register', async (req, res) => {
  const { username, password } = req.body;
  const hashedPassword = await bcrypt.hash(password, 10);
  pool.query('INSERT INTO users (username, password) VALUES (?, ?)', [username, hashedPassword], (err, results) => {
    if (err) return res.status(500).json({ error: 'Erreur lors de l’inscription' });
    res.json({ message: 'Inscription réussie' });
  });
});

// Endpoint pour la connexion
router.post('/login', (req, res) => {
  const { username, password } = req.body;
  pool.query('SELECT * FROM users WHERE username = ?', [username], async (err, results) => {
    if (err || results.length === 0) return res.status(401).json({ error: 'Utilisateur non trouvé' });
    const user = results[0];
    const valid = await bcrypt.compare(password, user.password);
    if (!valid) return res.status(401).json({ error: 'Mot de passe incorrect' });
    const token = jwt.sign({ id: user.id, username: user.username }, secretKey, { expiresIn: '1h' });
    res.json({ token });
  });
});

module.exports = router;
