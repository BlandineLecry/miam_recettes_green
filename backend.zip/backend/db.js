const mysql = require("mysql2/promise");

const db = mysql.createPool({
  host: "localhost",
  user: "root",
  password: "NouveauMotDePasse",
  database: "green_it",
});

module.exports = db;
