// recipes.js
const express = require("express");
const pool = require("./db");
const verifyToken = require("./authmiddleware");

const router = express.Router();

// Récupérer les recettes avec option de recherche
router.get("/", (req, res) => {
  let query = "SELECT * FROM recettes";
  const params = [];
  if (req.query.search) {
    query += " WHERE title LIKE ?";
    params.push(`%${req.query.search}%`);
  }
  pool.query(query, params, (err, results) => {
    if (err)
      return res.status(500).json({ error: "Erreur lors de la récupération" });
    res.json(results);
  });
});

// Ajouter une recette
router.post("/", verifyToken, (req, res) => {
  const { title, ingredients, instructions } = req.body;
  pool.query(
    "INSERT INTO recipes (title, ingredients, instructions, user_id) VALUES (?, ?, ?, ?)",
    [title, ingredients, instructions, req.user.id],
    (err, results) => {
      if (err)
        return res
          .status(500)
          .json({ error: "Erreur lors de l’ajout de la recette" });
      res.json({ message: "Recette ajoutée" });
    }
  );
});

// Supprimer une recette
router.delete("/:id", verifyToken, (req, res) => {
  const recipeId = req.params.id;
  // On peut vérifier que la recette appartient bien à l'utilisateur connecté
  pool.query(
    "DELETE FROM recipes WHERE id = ? AND user_id = ?",
    [recipeId, req.user.id],
    (err, results) => {
      if (err || results.affectedRows === 0)
        return res
          .status(500)
          .json({
            error: "Erreur lors de la suppression ou recette introuvable",
          });
      res.json({ message: "Recette supprimée" });
    }
  );
});

module.exports = router;
